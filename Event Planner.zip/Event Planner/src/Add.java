import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JSpinner;
import javax.swing.JEditorPane;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Add extends JFrame {

	private JPanel contentPane;
	private JTextField textNamField;
	private JTextField textEmailField;
	private JTextField textMobField;
	private JPasswordField passwordField;
	private JTextField textUserNField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Add frame = new Add();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Add() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 394, 479);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 102, 204));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 153, 255));
		panel.setBounds(0, 0, 378, 32);
		contentPane.add(panel);
		
		JLabel lblNewLabel = new JLabel("Add  a  User");
		lblNewLabel.setFont(new Font("Perpetua", Font.BOLD, 17));
		lblNewLabel.setForeground(new Color(204, 0, 51));
		panel.add(lblNewLabel);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBounds(0, 33, 378, 10);
		contentPane.add(panel_1);
		
		JLabel lblNewLabel_1 = new JLabel("Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(10, 76, 46, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Gender");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(10, 112, 46, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_4 = new JLabel("Email");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(10, 150, 46, 14);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_5 = new JLabel("Mobile");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_5.setBounds(10, 188, 46, 14);
		contentPane.add(lblNewLabel_5);
		
		textNamField = new JTextField();
		textNamField.setFont(new Font("Nirmala UI", Font.BOLD, 12));
		textNamField.setBounds(114, 73, 137, 20);
		contentPane.add(textNamField);
		textNamField.setColumns(10);
		
		JComboBox comboGenBox = new JComboBox();
		comboGenBox.setFont(new Font("Tahoma", Font.BOLD, 12));
		comboGenBox.setBounds(114, 109, 137, 22);
		contentPane.add(comboGenBox);
		comboGenBox.addItem("Choose Gender");
		comboGenBox.addItem("Male");
		comboGenBox.addItem("Female");
		comboGenBox.addItem("Others");
		
		textEmailField = new JTextField();
		textEmailField.setFont(new Font("Tahoma", Font.BOLD, 12));
		textEmailField.setBounds(114, 148, 199, 20);
		contentPane.add(textEmailField);
		textEmailField.setColumns(10);
		
		textMobField = new JTextField();
		textMobField.setFont(new Font("Tahoma", Font.BOLD, 11));
		textMobField.setBounds(114, 186, 120, 20);
		contentPane.add(textMobField);
		textMobField.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("User Name");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(10, 223, 77, 14);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_6 = new JLabel("Password");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_6.setBounds(10, 258, 77, 14);
		contentPane.add(lblNewLabel_6);
		
		passwordField = new JPasswordField();
		passwordField.setFont(new Font("Tahoma", Font.BOLD, 12));
		passwordField.setBounds(114, 256, 128, 20);
		contentPane.add(passwordField);
			
		textUserNField = new JTextField();
		textUserNField.setFont(new Font("Tahoma", Font.BOLD, 12));
		textUserNField.setColumns(10);
		textUserNField.setBounds(114, 221, 137, 20);
		contentPane.add(textUserNField);
		
		JButton btnNewButton = new JButton("Add");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
				       Class.forName("com.mysql.cj.jdbc.Driver");
				       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event_planner?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
				       Statement stmt = con.createStatement();
								String insertRow = "insert into usersofeventplan(name1,gender,email,mobile,user_name,pass)values(?,?,?,?,?,?)";
								PreparedStatement ps = con.prepareStatement(insertRow);
								ps.setString(1,textNamField.getText());
								String val = comboGenBox.getSelectedItem().toString();
								ps.setString(2,val);
								ps.setString(3,textEmailField.getText());
								ps.setString(4,textMobField.getText());
								ps.setString(5,textUserNField.getText());
								ps.setString(6,new String(passwordField.getPassword()));
								
								int rowsinserted = ps.executeUpdate();
								if( rowsinserted>1) {
									JOptionPane.showMessageDialog(null, "Information Saved");
									LogIn a = new LogIn();
									a.setVisible(true);
									dispose();
								}
								else
									JOptionPane.showMessageDialog(null, "Incorrect User Name or Password!");
								con.close();
							}catch(Exception ee) {
								JOptionPane.showMessageDialog(null, "Incorrect User Name or Password!");
							}
					Main m = new Main();
					m.setVisible(true);
					dispose();
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton.setBounds(114, 301, 89, 23);
		contentPane.add(btnNewButton);
	}
}
