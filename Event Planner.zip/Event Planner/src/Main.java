import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JToolBar;
import javax.swing.JToggleButton;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class Main extends JFrame {

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		getContentPane().setBackground(Color.CYAN);
		setBounds(100, 100, 455, 356);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JButton btnNewButton = new JButton("Sign Up");
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton.setBounds(96, 208, 89, 23);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
				Add a = new Add();
				a.setVisible(true);
				dispose();
			
			}
		});
		getContentPane().setLayout(null);
		getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("Welcome to Event Planner");
		lblNewLabel.setBounds(98, 35, 254, 30);
		lblNewLabel.setFont(new Font("Script MT Bold", Font.BOLD, 20));
		lblNewLabel.setForeground(Color.BLUE);
		getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Please Sign Up Or Log In");
		lblNewLabel_1.setForeground(new Color(0, 0, 255));
		lblNewLabel_1.setFont(new Font("Lucida Handwriting", Font.BOLD, 17));
		lblNewLabel_1.setBackground(new Color(0, 0, 255));
		lblNewLabel_1.setBounds(72, 161, 308, 36);
		getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton_1 = new JButton("Log In");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 13));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				LogIn a = new LogIn();
				a.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setBounds(212, 208, 89, 23);
		getContentPane().add(btnNewButton_1);

	}
}
