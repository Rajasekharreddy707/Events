import java.sql.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Color;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class EventHan extends JFrame {

	private JPanel contentPane;
	private JTextField ename;
	private JTextField esdate;
	private JTextField eddate;
	private JTextField enoguests;
	private JTextField a;
	private JTextField b;
	private JTextField ecost;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EventHan frame = new EventHan();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public EventHan() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 443, 502);
		contentPane = new JPanel();
		contentPane.setBackground(Color.BLUE);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.CYAN);
		panel.setBounds(0, 0, 434, 40);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add an Event");
		lblNewLabel.setFont(new Font("Perpetua Titling MT", Font.BOLD, 18));
		lblNewLabel.setBounds(133, 11, 183, 29);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Event Name");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_1.setBounds(23, 80, 90, 14);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("Event Address");
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_2.setBounds(23, 110, 107, 14);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_3 = new JLabel("Start Date");
		lblNewLabel_3.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_3.setBounds(23, 179, 124, 14);
		contentPane.add(lblNewLabel_3);
		
		JTextArea eaddress = new JTextArea();
		eaddress.setForeground(Color.BLACK);
		eaddress.setBackground(Color.WHITE);
		eaddress.setFont(new Font("Monospaced", Font.BOLD, 11));
		eaddress.setBounds(174, 108, 243, 52);
		contentPane.add(eaddress);
		
		ename = new JTextField();
		ename.setFont(new Font("Tahoma", Font.BOLD, 11));
		ename.setBounds(174, 78, 173, 20);
		contentPane.add(ename);
		ename.setColumns(10);
		
		esdate = new JTextField();
		esdate.setFont(new Font("Tahoma", Font.BOLD, 13));
		esdate.setBounds(174, 177, 107, 20);
		contentPane.add(esdate);
		esdate.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("End Date");
		lblNewLabel_4.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_4.setBounds(25, 219, 88, 14);
		contentPane.add(lblNewLabel_4);
		
		eddate = new JTextField();
		eddate.setFont(new Font("Tahoma", Font.BOLD, 13));
		eddate.setBounds(174, 217, 107, 20);
		contentPane.add(eddate);
		eddate.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("No. of Guests");
		lblNewLabel_5.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_5.setBounds(23, 255, 107, 14);
		contentPane.add(lblNewLabel_5);
		
		enoguests = new JTextField();
		enoguests.setFont(new Font("Tahoma", Font.BOLD, 9));
		enoguests.setBounds(173, 253, 49, 20);
		contentPane.add(enoguests);
		enoguests.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("Decoration Charge");
		lblNewLabel_6.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_6.setBounds(23, 301, 124, 14);
		contentPane.add(lblNewLabel_6);
		
		a = new JTextField();
		a.setFont(new Font("Tahoma", Font.BOLD, 11));
		a.setToolTipText("");
		a.setBounds(173, 299, 66, 20);
		contentPane.add(a);
		a.setColumns(10);
		
		JLabel lblNewLabel_7 = new JLabel("Catering charge");
		lblNewLabel_7.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_7.setBounds(23, 337, 107, 14);
		contentPane.add(lblNewLabel_7);
		
		b = new JTextField();
		b.setFont(new Font("Tahoma", Font.BOLD, 12));
		b.setBounds(174, 335, 65, 20);
		contentPane.add(b);
		b.setColumns(10);
		
		JLabel lblNewLabel_8 = new JLabel("Total Charge");
		lblNewLabel_8.setFont(new Font("Tahoma", Font.BOLD, 12));
		lblNewLabel_8.setBounds(23, 372, 98, 14);
		contentPane.add(lblNewLabel_8);
		
		ecost = new JTextField();
		ecost.setBounds(174, 366, 66, 20);
		contentPane.add(ecost);
		ecost.setColumns(10);
		
		JButton btnNewButton = new JButton("Add Event");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
				       Class.forName("com.mysql.jdbc.Driver");
				       Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/event_planner?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","");
				       Statement stmt = con.createStatement();
								String insertRow = "insert into eventplanned(ename,eaddress,esdate,eddate,enoguest,ecost)values(?,?,?,?,?,?)";
								PreparedStatement ps = con.prepareStatement(insertRow);
								ps.setString(1,ename.getText());
								ps.setString(2,eaddress.getText());
								ps.setString(3,esdate.getText());
								ps.setString(4,eddate.getText());
								ps.setString(5,enoguests.getText());
								int n,m,c;
								n = Integer.parseInt(a.getText());
								m = Integer.parseInt(b.getText());
								c=m+n;
								ecost.setText(Integer.toString(c));
								ps.setString(6,ecost.getText());
								
								int rowsinserted = ps.executeUpdate();
								if( rowsinserted>0)
									JOptionPane.showMessageDialog(null, "Details Added");
								else
									JOptionPane.showMessageDialog(null, "Wrong Entry !");
								con.close();
							}catch(Exception ee) {
								JOptionPane.showMessageDialog(null, "Wrong Entry !");
							}
				
				
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 11));
		btnNewButton.setBounds(104, 418, 89, 23);
		contentPane.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Proceed to Pay");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Payment p = new Payment();
				p.setVisible(true);
				dispose();
			}
		});
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 12));
		btnNewButton_1.setBounds(218, 418, 146, 23);
		contentPane.add(btnNewButton_1);
	}
}
